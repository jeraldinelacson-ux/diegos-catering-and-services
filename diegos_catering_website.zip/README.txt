DIEGO'S CATERING AND SERVICES WEBSITE

Files:
- index.html: responsive one-page website.

PREVIEW:
Open index.html in a web browser.

BEFORE PUBLISHING:
- Verify phone numbers, Facebook Page link, prices and package inclusions.
- Confirm menu availability and free inclusions.
- Test the inquiry form on desktop and mobile.

FREE HOSTING:
GitHub Pages: https://pages.github.com/
Google Sites: https://sites.google.com/

To publish this HTML with GitHub Pages:
1. Sign in/create a GitHub account.
2. Create a public repository, e.g. diegos-catering-website.
3. Upload index.html to the repository root.
4. Open repository Settings > Pages.
5. Choose Deploy from a branch, select main and /(root), then Save.
6. Wait for the published URL shown in Settings > Pages.

GitHub Pages provides a free github.io subdomain. A custom domain such as diegoscatering.com usually costs money.
